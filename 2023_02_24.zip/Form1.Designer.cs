﻿namespace _2023_02_24
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ball_01 = new System.Windows.Forms.PictureBox();
            this.ball_02 = new System.Windows.Forms.PictureBox();
            this.ball_03 = new System.Windows.Forms.PictureBox();
            this.ball_04 = new System.Windows.Forms.PictureBox();
            this.ball_06 = new System.Windows.Forms.PictureBox();
            this.ball_07 = new System.Windows.Forms.PictureBox();
            this.ball_08 = new System.Windows.Forms.PictureBox();
            this.ball_05 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.o_doctor = new System.Windows.Forms.PictureBox();
            this.ball_09 = new System.Windows.Forms.PictureBox();
            this.ball_10 = new System.Windows.Forms.PictureBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.result_check = new System.Windows.Forms.Button();
            this.ball_se_01 = new System.Windows.Forms.RadioButton();
            this.ball_se_06 = new System.Windows.Forms.RadioButton();
            this.ball_se_02 = new System.Windows.Forms.RadioButton();
            this.ball_se_07 = new System.Windows.Forms.RadioButton();
            this.ball_se_03 = new System.Windows.Forms.RadioButton();
            this.ball_se_08 = new System.Windows.Forms.RadioButton();
            this.ball_se_04 = new System.Windows.Forms.RadioButton();
            this.ball_se_09 = new System.Windows.Forms.RadioButton();
            this.ball_se_05 = new System.Windows.Forms.RadioButton();
            this.ball_se_10 = new System.Windows.Forms.RadioButton();
            this.restart = new System.Windows.Forms.Button();
            this.reset = new System.Windows.Forms.Button();
            this.price_show = new System.Windows.Forms.TextBox();
            this.purchase = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ball_01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.o_doctor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_10)).BeginInit();
            this.SuspendLayout();
            // 
            // ball_01
            // 
            this.ball_01.Location = new System.Drawing.Point(211, 230);
            this.ball_01.Name = "ball_01";
            this.ball_01.Size = new System.Drawing.Size(143, 141);
            this.ball_01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ball_01.TabIndex = 0;
            this.ball_01.TabStop = false;
            // 
            // ball_02
            // 
            this.ball_02.Location = new System.Drawing.Point(360, 230);
            this.ball_02.Name = "ball_02";
            this.ball_02.Size = new System.Drawing.Size(143, 141);
            this.ball_02.TabIndex = 1;
            this.ball_02.TabStop = false;
            // 
            // ball_03
            // 
            this.ball_03.Location = new System.Drawing.Point(509, 230);
            this.ball_03.Name = "ball_03";
            this.ball_03.Size = new System.Drawing.Size(143, 141);
            this.ball_03.TabIndex = 2;
            this.ball_03.TabStop = false;
            // 
            // ball_04
            // 
            this.ball_04.Location = new System.Drawing.Point(658, 230);
            this.ball_04.Name = "ball_04";
            this.ball_04.Size = new System.Drawing.Size(143, 141);
            this.ball_04.TabIndex = 3;
            this.ball_04.TabStop = false;
            // 
            // ball_06
            // 
            this.ball_06.Location = new System.Drawing.Point(211, 407);
            this.ball_06.Name = "ball_06";
            this.ball_06.Size = new System.Drawing.Size(143, 141);
            this.ball_06.TabIndex = 4;
            this.ball_06.TabStop = false;
            // 
            // ball_07
            // 
            this.ball_07.Location = new System.Drawing.Point(360, 407);
            this.ball_07.Name = "ball_07";
            this.ball_07.Size = new System.Drawing.Size(143, 141);
            this.ball_07.TabIndex = 5;
            this.ball_07.TabStop = false;
            // 
            // ball_08
            // 
            this.ball_08.Location = new System.Drawing.Point(509, 407);
            this.ball_08.Name = "ball_08";
            this.ball_08.Size = new System.Drawing.Size(143, 141);
            this.ball_08.TabIndex = 6;
            this.ball_08.TabStop = false;
            // 
            // ball_05
            // 
            this.ball_05.Location = new System.Drawing.Point(807, 230);
            this.ball_05.Name = "ball_05";
            this.ball_05.Size = new System.Drawing.Size(143, 141);
            this.ball_05.TabIndex = 7;
            this.ball_05.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::_2023_02_24.Properties.Resources.Pokemon_Logo;
            this.pictureBox9.Location = new System.Drawing.Point(12, 3);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(590, 221);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox9.TabIndex = 8;
            this.pictureBox9.TabStop = false;
            // 
            // o_doctor
            // 
            this.o_doctor.Location = new System.Drawing.Point(12, 230);
            this.o_doctor.Name = "o_doctor";
            this.o_doctor.Size = new System.Drawing.Size(193, 318);
            this.o_doctor.TabIndex = 9;
            this.o_doctor.TabStop = false;
            // 
            // ball_09
            // 
            this.ball_09.Location = new System.Drawing.Point(658, 407);
            this.ball_09.Name = "ball_09";
            this.ball_09.Size = new System.Drawing.Size(143, 141);
            this.ball_09.TabIndex = 10;
            this.ball_09.TabStop = false;
            // 
            // ball_10
            // 
            this.ball_10.Location = new System.Drawing.Point(807, 407);
            this.ball_10.Name = "ball_10";
            this.ball_10.Size = new System.Drawing.Size(143, 141);
            this.ball_10.TabIndex = 11;
            this.ball_10.TabStop = false;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(609, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(341, 199);
            this.listBox1.TabIndex = 12;
            // 
            // result_check
            // 
            this.result_check.Location = new System.Drawing.Point(278, 582);
            this.result_check.Name = "result_check";
            this.result_check.Size = new System.Drawing.Size(153, 60);
            this.result_check.TabIndex = 13;
            this.result_check.Text = "결정";
            this.result_check.UseVisualStyleBackColor = true;
            this.result_check.Click += new System.EventHandler(this.result_check_Click);
            // 
            // ball_se_01
            // 
            this.ball_se_01.AutoSize = true;
            this.ball_se_01.Location = new System.Drawing.Point(251, 375);
            this.ball_se_01.Name = "ball_se_01";
            this.ball_se_01.Size = new System.Drawing.Size(43, 19);
            this.ball_se_01.TabIndex = 14;
            this.ball_se_01.TabStop = true;
            this.ball_se_01.Text = "???";
            this.ball_se_01.UseVisualStyleBackColor = true;
            // 
            // ball_se_06
            // 
            this.ball_se_06.AutoSize = true;
            this.ball_se_06.Location = new System.Drawing.Point(251, 552);
            this.ball_se_06.Name = "ball_se_06";
            this.ball_se_06.Size = new System.Drawing.Size(43, 19);
            this.ball_se_06.TabIndex = 15;
            this.ball_se_06.TabStop = true;
            this.ball_se_06.Text = "???";
            this.ball_se_06.UseVisualStyleBackColor = true;
            // 
            // ball_se_02
            // 
            this.ball_se_02.AutoSize = true;
            this.ball_se_02.Location = new System.Drawing.Point(400, 375);
            this.ball_se_02.Name = "ball_se_02";
            this.ball_se_02.Size = new System.Drawing.Size(43, 19);
            this.ball_se_02.TabIndex = 16;
            this.ball_se_02.TabStop = true;
            this.ball_se_02.Text = "???";
            this.ball_se_02.UseVisualStyleBackColor = true;
            // 
            // ball_se_07
            // 
            this.ball_se_07.AutoSize = true;
            this.ball_se_07.Location = new System.Drawing.Point(400, 552);
            this.ball_se_07.Name = "ball_se_07";
            this.ball_se_07.Size = new System.Drawing.Size(43, 19);
            this.ball_se_07.TabIndex = 17;
            this.ball_se_07.TabStop = true;
            this.ball_se_07.Text = "???";
            this.ball_se_07.UseVisualStyleBackColor = true;
            // 
            // ball_se_03
            // 
            this.ball_se_03.AutoSize = true;
            this.ball_se_03.Location = new System.Drawing.Point(549, 375);
            this.ball_se_03.Name = "ball_se_03";
            this.ball_se_03.Size = new System.Drawing.Size(43, 19);
            this.ball_se_03.TabIndex = 18;
            this.ball_se_03.TabStop = true;
            this.ball_se_03.Text = "???";
            this.ball_se_03.UseVisualStyleBackColor = true;
            // 
            // ball_se_08
            // 
            this.ball_se_08.AutoSize = true;
            this.ball_se_08.Location = new System.Drawing.Point(549, 552);
            this.ball_se_08.Name = "ball_se_08";
            this.ball_se_08.Size = new System.Drawing.Size(43, 19);
            this.ball_se_08.TabIndex = 19;
            this.ball_se_08.TabStop = true;
            this.ball_se_08.Text = "???";
            this.ball_se_08.UseVisualStyleBackColor = true;
            // 
            // ball_se_04
            // 
            this.ball_se_04.AutoSize = true;
            this.ball_se_04.Location = new System.Drawing.Point(698, 375);
            this.ball_se_04.Name = "ball_se_04";
            this.ball_se_04.Size = new System.Drawing.Size(43, 19);
            this.ball_se_04.TabIndex = 20;
            this.ball_se_04.TabStop = true;
            this.ball_se_04.Text = "???";
            this.ball_se_04.UseVisualStyleBackColor = true;
            // 
            // ball_se_09
            // 
            this.ball_se_09.AutoSize = true;
            this.ball_se_09.Location = new System.Drawing.Point(698, 552);
            this.ball_se_09.Name = "ball_se_09";
            this.ball_se_09.Size = new System.Drawing.Size(43, 19);
            this.ball_se_09.TabIndex = 21;
            this.ball_se_09.TabStop = true;
            this.ball_se_09.Text = "???";
            this.ball_se_09.UseVisualStyleBackColor = true;
            // 
            // ball_se_05
            // 
            this.ball_se_05.AutoSize = true;
            this.ball_se_05.Location = new System.Drawing.Point(847, 375);
            this.ball_se_05.Name = "ball_se_05";
            this.ball_se_05.Size = new System.Drawing.Size(43, 19);
            this.ball_se_05.TabIndex = 22;
            this.ball_se_05.TabStop = true;
            this.ball_se_05.Text = "???";
            this.ball_se_05.UseVisualStyleBackColor = true;
            // 
            // ball_se_10
            // 
            this.ball_se_10.AutoSize = true;
            this.ball_se_10.Location = new System.Drawing.Point(847, 552);
            this.ball_se_10.Name = "ball_se_10";
            this.ball_se_10.Size = new System.Drawing.Size(43, 19);
            this.ball_se_10.TabIndex = 23;
            this.ball_se_10.TabStop = true;
            this.ball_se_10.Text = "???";
            this.ball_se_10.UseVisualStyleBackColor = true;
            // 
            // restart
            // 
            this.restart.Location = new System.Drawing.Point(437, 582);
            this.restart.Name = "restart";
            this.restart.Size = new System.Drawing.Size(153, 60);
            this.restart.TabIndex = 24;
            this.restart.Text = "다시 뽑기";
            this.restart.UseVisualStyleBackColor = true;
            this.restart.Click += new System.EventHandler(this.restart_Click);
            // 
            // reset
            // 
            this.reset.Location = new System.Drawing.Point(596, 582);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(153, 60);
            this.reset.TabIndex = 25;
            this.reset.Text = "초기화";
            this.reset.UseVisualStyleBackColor = true;
            this.reset.Click += new System.EventHandler(this.reset_Click_1);
            // 
            // price_show
            // 
            this.price_show.Location = new System.Drawing.Point(12, 602);
            this.price_show.Name = "price_show";
            this.price_show.Size = new System.Drawing.Size(193, 23);
            this.price_show.TabIndex = 26;
            // 
            // purchase
            // 
            this.purchase.Location = new System.Drawing.Point(797, 582);
            this.purchase.Name = "purchase";
            this.purchase.Size = new System.Drawing.Size(153, 60);
            this.purchase.TabIndex = 27;
            this.purchase.Text = "구매";
            this.purchase.UseVisualStyleBackColor = true;
            this.purchase.Click += new System.EventHandler(this.purchase_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(961, 654);
            this.Controls.Add(this.purchase);
            this.Controls.Add(this.price_show);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.restart);
            this.Controls.Add(this.ball_se_10);
            this.Controls.Add(this.ball_se_05);
            this.Controls.Add(this.ball_se_09);
            this.Controls.Add(this.ball_se_04);
            this.Controls.Add(this.ball_se_08);
            this.Controls.Add(this.ball_se_03);
            this.Controls.Add(this.ball_se_07);
            this.Controls.Add(this.ball_se_02);
            this.Controls.Add(this.ball_se_06);
            this.Controls.Add(this.ball_se_01);
            this.Controls.Add(this.result_check);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.ball_10);
            this.Controls.Add(this.ball_09);
            this.Controls.Add(this.o_doctor);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.ball_05);
            this.Controls.Add(this.ball_08);
            this.Controls.Add(this.ball_07);
            this.Controls.Add(this.ball_06);
            this.Controls.Add(this.ball_04);
            this.Controls.Add(this.ball_03);
            this.Controls.Add(this.ball_02);
            this.Controls.Add(this.ball_01);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ball_01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.o_doctor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball_10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox ball_01;
        private System.Windows.Forms.PictureBox ball_02;
        private System.Windows.Forms.PictureBox ball_03;
        private System.Windows.Forms.PictureBox ball_04;
        private System.Windows.Forms.PictureBox ball_06;
        private System.Windows.Forms.PictureBox ball_07;
        private System.Windows.Forms.PictureBox ball_08;
        private System.Windows.Forms.PictureBox ball_05;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox o_doctor;
        private System.Windows.Forms.PictureBox ball_09;
        private System.Windows.Forms.PictureBox ball_10;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button result_check;
        private System.Windows.Forms.RadioButton ball_se_01;
        private System.Windows.Forms.RadioButton ball_se_06;
        private System.Windows.Forms.RadioButton ball_se_02;
        private System.Windows.Forms.RadioButton ball_se_07;
        private System.Windows.Forms.RadioButton ball_se_03;
        private System.Windows.Forms.RadioButton ball_se_08;
        private System.Windows.Forms.RadioButton ball_se_04;
        private System.Windows.Forms.RadioButton ball_se_09;
        private System.Windows.Forms.RadioButton ball_se_05;
        private System.Windows.Forms.RadioButton ball_se_10;
        private System.Windows.Forms.Button restart;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.TextBox price_show;
        private System.Windows.Forms.Button purchase;
    }
}
